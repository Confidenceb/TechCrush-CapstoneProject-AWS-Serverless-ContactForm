const express = require('express');
const auth = require('../middleware/auth');  // ✅ Fixed path
const { dynamo } = require('../config/aws');
const router = express.Router();

const FILES_TABLE = process.env.DYNAMO_FILE_TABLE;  // ✅ Fixed env name

router.get('/', auth, async (req, res) => {
  try {
    const params = {
      TableName: FILES_TABLE,
      KeyConditionExpression: 'userId = :uid',
      ExpressionAttributeValues: {
        ':uid': req.user.id
      }
    };

    const result = await dynamo.query(params).promise();
    res.json({ files: result.Items || [] });
  } catch (err) {
    console.error('Error fetching user files:', err);
    res.status(500).json({ message: 'Failed to fetch files' });
  }
});

module.exports = router;