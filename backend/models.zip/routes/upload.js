const express = require('express');
const multer = require('multer');
const uploadFile = require('../utils/upload'); // <-- IMPORT S3 helper
const router = express.Router();
const { saveFileMetadata } = require('../models/file');
const auth = require('../middleware/auth'); // <-- ADD THIS


// Configure multer
const upload = multer();

// POST /api/upload
router.post('/', auth, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ message: 'No file uploaded' });

    // Upload to S3
    const result = await uploadFile(req.file, `uploads/${req.file.originalname}`);

    // Save metadata to DynamoDB
    const fileMetadata = {
      userId: String(req.user.id),
      id: Date.now().toString(),
      name: req.file.originalname,
      size: (req.file.size / 1024).toFixed(2) + ' KB',
      type: req.file.mimetype,
      url: result.Location,
      date: new Date().toLocaleDateString()
    };
    await saveFileMetadata(fileMetadata);

    res.json({ file: fileMetadata });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


module.exports = router; // <-- EXPORT
