const { dynamo } = require('../config/aws');
const TABLE_NAME = process.env.DYNAMO_USER_TABLE;

async function createUser(user) {
  const params = {
    TableName: TABLE_NAME,
    Item: user,
    ConditionExpression: 'attribute_not_exists(email)'
  };
  return dynamo.put(params).promise();
}

async function getUserByEmail(email) {
  const params = {
    TableName: TABLE_NAME,
    FilterExpression: 'email = :email',  // ✅ Fixed
    ExpressionAttributeValues: {
      ':email': email
    }
  };
  const result = await dynamo.scan(params).promise();
  return result.Items[0];  // ✅ Fixed
}

module.exports = { createUser, getUserByEmail };