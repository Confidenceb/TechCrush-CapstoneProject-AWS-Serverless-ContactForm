// models/file.js
const { dynamo } = require('../config/aws');
const TABLE_NAME = process.env.DYNAMO_FILE_TABLE; // e.g., "Files"

async function saveFileMetadata(file) {
  const params = {
    TableName: TABLE_NAME,
    Item: file
  };
  return dynamo.put(params).promise();
}

async function getFilesByUser(userId) {
  const params = {
    TableName: TABLE_NAME,
    KeyConditionExpression: 'userId = :uid',
    ExpressionAttributeValues: {
      ':uid': userId
    }
  };
  const result = await dynamo.query(params).promise();
  return result.Items;
}

module.exports = { saveFileMetadata, getFilesByUser };
